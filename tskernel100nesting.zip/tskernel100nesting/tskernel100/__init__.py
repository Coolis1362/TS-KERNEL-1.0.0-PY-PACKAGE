__version__ = "1.0.0"

from .launcher import launch_kernel
