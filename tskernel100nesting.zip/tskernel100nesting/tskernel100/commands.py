import time
import os

def execute_command(command, kernel_version):
    if command == "help":
        print("Commands:")
        print("help - Show this help message")
        print("exit - Exit the console")
        print("clear - Clear the console")
        print("version - Show the current kernel version")
        print("add your commands here") # Extend functionality as needed

    elif command == "exit":
        print("Exiting TS-KERNEL...")
        time.sleep(1)
        os.system("taskkill /F /IM cmd.exe")
        os._exit(0)

    elif command == "clear":
        os.system("cls" if os.name == "nt" else "clear")

    elif command == "version":
        print(f"TS-KERNEL Version: {kernel_version}")

    else:
        print(f"Unknown command: '{command}'. Type 'help' for a list of commands.")
