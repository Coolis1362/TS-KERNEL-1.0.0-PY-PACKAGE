import time
import os
from .commands import execute_command

def launch_kernel():
    KERNEL_VERSION = "1.0.0"
    print(f"Welcome to TS-KERNEL {KERNEL_VERSION}!")
    time.sleep(2)
    print("Initializing TS-KERNEL...")
    time.sleep(2)
    print("Loading...")
    time.sleep(2)
    for step in range(100):
        print("#", end="", flush=True)
        time.sleep(0.05)

    os.system("cls" if os.name == "nt" else "clear")
    time.sleep(2)
    print("***************************************************************")
    print("*                  WELCOME TO TS-KERNEL                      *")
    print("*                     NO COPYRIGHT                           *")
    print("*             BUILT FOR CUSTOMIZATION AND EXPANSION          *")
    print("*                  TYPE 'help' FOR COMMANDS                  *")
    print("***************************************************************")

    while True:
        kernel_command = input(f"CONSOLE FOR TS-KERNEL {KERNEL_VERSION}>>>> ")
        execute_command(kernel_command, KERNEL_VERSION)
